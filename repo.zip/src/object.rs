use crate::ray::*;
use crate::vec3::*;
use crate::material2::*;

type T = f32;

pub struct HitResult {
  pub p: Point,
  pub normal: Vec3,
  pub t: T,
  pub front_face: bool,
  pub material: Material,
}

impl HitResult {
  pub fn new(p: &Point, r: &Ray, t: T, outward_normal: &Vec3, material: Material) -> HitResult {
    let front_face = r.direction.dot(outward_normal) < 0.0;
    HitResult {
      p: *p,
      normal: if front_face {
        *outward_normal
      } else {
        -*outward_normal
      },
      t: t,
      front_face: front_face,
      material: material,
    }
  }
}

pub trait Object {
  fn hit(&self, t_min: T, t_max: T, ray: &Ray) -> Option<HitResult>;
}

pub struct Sphere {
  center: Point,
  radius: T,
  material: Material,
}

impl Sphere {
  pub fn new(center: Point, radius: T, material: Material) -> Sphere {
    Sphere {
      center: center,
      radius: radius,
      material: material,
    }
  }
}

impl Sphere {
  fn hits_sphere(&self, t_min: T, t_max: T, ray: &Ray) -> T {
    let oc: Vec3 = ray.origin - self.center;
    let a = ray.direction.norm_squared();
    let half_b = oc.dot(&ray.direction);
    let c = oc.norm_squared() - self.radius * self.radius;
    let discriminant = half_b * half_b - a * c;
    if discriminant < 0.0 {
      return -1.0;
    }
    let sqrtd = discriminant.sqrt();
    let valid_t = |t: T| -> bool { t >= t_min && t <= t_max };
    let mut root = (-half_b - sqrtd) / a;
    if !valid_t(root) {
      root = (-half_b + sqrtd) / a;
      if !valid_t(root) {
        return -1.0;
      }
    }
    return root;
  }
}

impl Object for Sphere {
  fn hit(&self, t_min: T, t_max: T, ray: &Ray) -> Option<HitResult> {
    let t = self.hits_sphere(t_min, t_max, ray);
    if t < 0.0 {
      None
    } else {
      let point = ray.at(t);
      let mut normal = point - self.center;
      normal /= self.radius;
      Some(HitResult::new(&point, ray, t, &normal, self.material))
    }
  }
}

pub struct ObjectList<'a> {
  objects: Vec<Box<dyn Object + Sync + Send + 'a>>,
}

impl<'a> ObjectList<'a> {
  pub fn new<'b>() -> ObjectList<'b> {
    ObjectList {
      objects: Vec::new(),
    }
  }
  pub fn add(&mut self, obj: Box<dyn Object + Sync + Send + 'a>) {
    self.objects.push(obj);
  }
}

impl Object for ObjectList<'_> {
  fn hit(&self, t_min: T, t_max: T, ray: &Ray) -> Option<HitResult> {
    let mut result: Option<HitResult> = None;
    let mut current_max = t_max;
    for obj in self.objects.iter() {
      match obj.hit(t_min, current_max, ray) {
        Some(hr) => {
          current_max = hr.t;
          result = Some(hr);
        }
        None => {}
      }
    }
    return result;
  }
}
