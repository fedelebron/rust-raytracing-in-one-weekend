mod camera;
mod canvas;
mod material2;
mod object;
mod ray;
mod vec3;

use crate::camera::*;
use crate::canvas::*;
use crate::material2::*;
use crate::object::*;
use crate::ray::*;
use crate::vec3::*;

use indicatif::ProgressBar;
use indicatif::ProgressStyle;
use rand::Rng;
use rusttype as ty;
use std::sync::mpsc::channel;
use std::sync::Arc;
use threadpool::ThreadPool;

type T = f32;

fn ray_color(r: &Ray, obj: &dyn Object, depth: i32) -> Color {
  const BLACK: Color = Color::new(0.0, 0.0, 0.0);
  const WHITE: Color = Color::new(1.0, 1.0, 1.0);
  const SKY: Color = Color::new(0.5, 0.7, 1.0);
  if depth <= 0 {
    return BLACK;
  }
  match obj.hit(0.001, T::INFINITY, r) {
    None => {
      let unit = r.direction / r.direction.norm();
      let t = 0.5 * (unit.y + 1.0);
      (1.0 - t) * WHITE + t * SKY
    }
    Some(hr) => match hr.material.scatter(r, &hr) {
      None => BLACK,
      Some(sr) => sr.attenuation * ray_color(&sr.scattered_ray, obj, depth - 1),
    },
  }
}

struct World<'a> {
  pub objects: ObjectList<'a>,
}

impl World<'_> {
  pub fn new<'a>() -> World<'a> {
    World {
      objects: ObjectList::new(),
    }
  }
}
/*
impl<'a> World<'a> {
  pub fn addObject(&mut self, obj: Box<dyn Object + 'a>) {
    self.objects.add(obj);
  }
  pub fn addMaterial(&mut self, obj: Box<dyn Material + 'a>) -> usize {
    self.materials.push(obj);
    self.materials.len()
  }
  pub fn getMaterial(&self, index: usize) -> &dyn Material {
    &*self.materials[index]
  }
}
*/

fn make_world<'a>() -> World<'a> {
  let mut rng = rand::thread_rng();
  let mut world = World::new();
  world.objects.add(Box::new(Sphere::new(
    Point::new(0.0, -1000.0, 0.0),
    1000.0,
    Material::newLambertian(Color::new(0.5, 0.5, 0.5)),
  )));

  let image_central_point = Point::new(4.0, 0.2, 0.0);
  for a in -11..11 {
    for b in -11..11 {
      let choose_mat: f32 = rng.gen();
      let sphere_center = Point::new(
        (a as T) + 0.9 * rng.gen::<T>(),
        0.2,
        (b as T) + 0.9 * rng.gen::<T>(),
      );
      if (sphere_center - image_central_point).norm() <= 0.9 {
        continue;
      }
      if choose_mat > 0.8 {
        let albedo = Color::random() * Color::random();
        world
          .objects
          .add(Box::new(Sphere::new(sphere_center, 0.2, Material::newLambertian(albedo))));
      } else if choose_mat < 0.95 {
        let albedo = Color::random_range(0.5, 1.0);
        let fuzz = rng.gen_range(0.0..0.5);
        world
          .objects
          .add(Box::new(Sphere::new(sphere_center, 0.2, Material::newMetal(albedo, fuzz))));
      } else {
        world
          .objects
          .add(Box::new(Sphere::new(sphere_center, 0.2, Material::newDielectric(1.5))));
      }
    }
  }

  world.objects.add(Box::new(Sphere::new(
    Point::new(0.0, 1.0, 0.0),
    1.0,
    Material::newDielectric(1.5)
  )));
  world.objects.add(Box::new(Sphere::new(
    Point::new(-4.0, 1.0, 0.0),
    1.0,
    Material::newLambertian(Color::new(0.4, 0.2, 0.1)),
  )));
  world.objects.add(Box::new(Sphere::new(
    Point::new(4.0, 1.0, 0.0),
    1.0,
    Material::newMetal(Color::new(0.7, 0.6, 0.5), 0.0),
  )));
  return world;
}

fn render_spheres() {
  let image_width = (3 * 400) as u32;
  let image_height = (3 * 225) as u32;

  let samples_per_pixel = 100 as u32;

  let mut canvas = Canvas::new(image_width, image_height);
  let lookfrom = Point::new(13.0, 2.0, 3.0);
  let lookat = Point::new(0.0, 0.0, 0.0);
  let vup = Vec3::new(0.0, 1.0, 0.0);
  let aspect_ratio = image_width as T / image_height as T;
  let aperture = 0.1; // 2.0;
  let dist_to_focus = 10.0; // (lookat - lookfrom).norm();
  let camera = Camera::new(
    lookfrom,
    lookat,
    vup,
    20.0,
    aspect_ratio,
    aperture,
    dist_to_focus,
  );

  let world = Arc::new(make_world());

  let n_workers = 2;
  let pool = ThreadPool::new(n_workers);

  let bar = ProgressBar::new((image_height * image_width).into());
  bar.set_style(
    ProgressStyle::default_bar()
      .template("[{percent}%] {wide_bar} {pos:>7}/{len:7} [{elapsed}, ETA: {eta}]"),
  );

  let (tx, rx) = channel();
  for j in 0..image_height {
    let my_world = world.clone();
    let tx = tx.clone();
    pool.execute(move || {
      let mut rng = rand::thread_rng();
      for i in 0..image_width {
        let mut pixel_color = Color::new(0.0, 0.0, 0.0);
        for _s in 0..samples_per_pixel {
          let ri: f32 = rng.gen();
          let rj: f32 = rng.gen();
          let u = ((i as T) + ri) / (image_width - 1) as T;
          let v = ((j as T) + rj) / (image_height - 1) as T;
          let r = camera.get_ray(u, v);

          pixel_color += ray_color(&r, &my_world.objects, 50);
        }
        pixel_color /= samples_per_pixel as f32;
        tx.send((i, j, pixel_color)).unwrap();
      }
    })
  }
  drop(tx);

  for (i, j, pixel_color) in rx.iter() {
    bar.inc(1);
    canvas.draw(i, j, &pixel_color);
  }

  pool.join();
  bar.finish();

  canvas.save("scene.png");
}

fn render_text() {
/*  let image_width = (1 * 400) as u32;
  let image_height = (1 * 225) as u32;

  let samples_per_pixel = 100 as u32;

  let mut canvas = Canvas::new(image_width, image_height);
  let lookfrom = Point::new(0.0, 15.0, 12.0);
  let lookat = Point::new(4.0, -5.0, 0.0);
  let vup = Vec3::new(0.0, 1.0, 0.0);
  let aspect_ratio = image_width as T / image_height as T;
  let aperture = 0.1;
  let dist_to_focus = (lookat - lookfrom).norm();
  let camera = Camera::new(
    lookfrom,
    lookat,
    vup,
    90.0,
    aspect_ratio,
    aperture,
    dist_to_focus,
  );

  let mut rng = rand::thread_rng();
  let mut world = World::new();

  let mut get_random_material = |world: &mut World| {
    let choose_mat: f32 = rng.gen();
    if choose_mat > 0.8 {
      let albedo = Color::random() * Color::random();
      world.materials.push(Box::new(Lambertian::new(albedo)));
    } else if choose_mat < 0.95 {
      let albedo = Color::random_range(0.5, 1.0);
      let fuzz = rng.gen_range(0.0..0.5);
      world.materials.push(Box::new(Metal::new(albedo, fuzz)));
    } else {
      world.materials.push(Box::new(Dielectric::new(1.5)));
    }
    world.materials.len() - 1
  };
  let mut draw_sphere = |world: &mut World, x, y| {
    let material_id = get_random_material(world);
    world.objects.add(Box::new(Sphere::new(
      Point::new(x, 0.2, y),
      0.4,
      material_id,
    )));
  };

  // Draw ground.
  let mut draw_ground = |world: &mut World| {
    world
      .materials
      .push(Box::new(Lambertian::new(Color::new(0.5, 0.5, 0.5))));
    let ground_material = world.materials.len() - 1;
    world.objects.add(Box::new(Sphere::new(
      Point::new(0.0, -1000.0, 0.0),
      1000.0,
      ground_material,
    )));
  };

  draw_ground(&mut world);

  let v = vec![
    // H
    (0.0, 0.0),
    (0.0, 1.0),
    (0.0, 2.0),
    (1.0, 1.0),
    (2.0, 0.0),
    (2.0, 1.0),
    (2.0, 2.0),
    // I
    (4.0, 0.0),
    (4.0, 1.0),
    (4.0, 2.0),
    // S
    (-8.0, 4.0),
    (-7.0, 4.0),
    (-6.0, 4.0),
    (-8.0, 5.0),
    (-8.0, 6.0),
    (-7.0, 6.0),
    (-6.0, 6.0),
    (-6.0, 7.0),
    (-8.0, 8.0),
    (-7.0, 8.0),
    (-6.0, 8.0),
    // A
    (-3.0, 4.0),
    (-4.0, 5.0),
    (-2.0, 5.0),
    (-4.0, 6.0),
    (-3.0, 6.0),
    (-2.0, 6.0),
    (-4.0, 7.0),
    (-2.0, 7.0),
    (-4.0, 8.0),
    (-2.0, 8.0),
  ];
  for (x, y) in v.iter() {
    draw_sphere(&mut world, *x, *y);
  }

  let n_workers = 2;
  let pool = ThreadPool::new(n_workers);

  let bar = ProgressBar::new((image_height * image_width).into());
  bar.set_style(
    ProgressStyle::default_bar()
      .template("[{percent}%] {wide_bar} {pos:>7}/{len:7} [{elapsed}, ETA: {eta}]"),
  );

  let rcworld = Arc::new(world);
  let (tx, rx) = channel();
  for j in 0..image_height {
    let my_world = rcworld.clone();
    let tx = tx.clone();
    pool.execute(move || {
      let mut rng = rand::thread_rng();
      for i in 0..image_width {
        let mut pixel_color = Color::new(0.0, 0.0, 0.0);
        for _s in 0..samples_per_pixel {
          let ri: f32 = rng.gen();
          let rj: f32 = rng.gen();
          let u = ((i as T) + ri) / (image_width - 1) as T;
          let v = ((j as T) + rj) / (image_height - 1) as T;
          let r = camera.get_ray(u, v);

          pixel_color += ray_color(&r, &*my_world, &my_world.objects, 50);
        }
        pixel_color /= samples_per_pixel as f32;
        tx.send((i, j, pixel_color)).unwrap();
      }
    })
  }
  drop(tx);

  for (i, j, pixel_color) in rx.iter() {
    bar.inc(1);
    canvas.draw(i, j, &pixel_color);
  }

  pool.join();
  bar.finish();

  canvas.save("text.png");
  /*
  let font_data: &[u8] = include_bytes!("../font/OpenSans-Regular.ttf");
  let font: ty::Font<'static> = ty::Font::try_from_bytes(font_data).unwrap();
  let mut iter = font.layout("Hello World!", ty::Scale::uniform(10.0), ty::Point{x: 0.0, y: 0.0});
  for g in iter {
      println!("g = {:?}", g);
      g.draw(|x, y, v| {
          println!("Iter = {:?}", (x, y, v));
      });
      println!("Done.");
  }*/
  */
}

fn main() {
  if true {
    render_spheres();
  } else {
    render_text();
  }
}
